<?php 
$alertBox = '';

?>