<?php
############################################################################
#
# this script is a port of Jerry Wilkins wxusradars-hanis3.php Version 5a (20190511)
# with additional mods by Ken True for inclusion in the Saratoga Base-USA template.
# Many thanks to Jerry for allowing the kind use of his code!
#
# Version 1.00 - 22-May-2020 - initial release
# Version 2.00 - 06-Apr-2021 - update to use radar.weather.gov/ridge/lite images
# Version 2.01 - 02-May-2021 - added composite radar images to list for display
# Version 2.02 - 08-Sep-2022 - update to use radar.weather.gov/ridge/standard images
# Version 2.03 - 15-Feb-2024 - sanitize $_POST inputs to fix XSS vulerability (Thanks dwhitemv on WXForum.net)
# Version 2.04 - 21-May-2026 - fixes for PHP 8.5
############################################################################
if (isset($_REQUEST['sce']) && strtolower($_REQUEST['sce']) == 'view' 
    and strlen($_REQUEST['sce']) == 4) {
   //--self downloader --
   $filenameReal = __FILE__;
   $download_size = filesize($filenameReal);
   header('Pragma: public');
   header('Cache-Control: private');
   header('Cache-Control: no-cache, must-revalidate');
   header("Content-type: text/plain");
   header("Accept-Ranges: bytes");
   header("Content-Length: $download_size");
   header('Connection: close');
   
   readfile($filenameReal);
   exit;
}
if (isset($_REQUEST['sce'])) {
  header("HTTP/1.1 403 Forbidden");
  print "<h1>Hacking attempt. Denied.</h1>\n";
  exit();
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
  <title>HAniS US Radar Animation</title>
  <script src="./hanis_min.js" type="text/javascript"></script>
<?php if (!isset($radar)) { // Load jquery library if needed
echo '<script src="//code.jquery.com/jquery-3.7.1.min.js" type="text/javascript"></script>';
} ?>
  </head>
<?php 
function sanitize($t) {
	return preg_replace('![^-a-zA-Z0-9]+!','',$t);
}

if (!isset($radar)) { // To test load some defaults if not called by 'wxnwsradar-inc.php'
  // you DON'T need to customize these.. change wxnwsradar.php instead.
	$radar = 'N0R'; // Default radar type is set here
	$radarLoc = 'mux'; // IMPORTAMT!!! Default radar location is set here
  // NOTE: use last 3 characters for Kxxx sites, 
  // use ALL 4 characters for Pxxx/Txxx sites (AK, HI, Guam, Puerto Rico)
	$imageWidth = 600; // Width of radar images
	$iframeWidth = 617; // Default IFrame Width -- adjust as needed
	$iframeHeight = 620; // Default IFrame Height -- adjust as needed
	$autoRefresh = true; // Use Autorefresh? true or false -- Determines whether AutoRefresh even appears
	$autoRefreshTime = 8; // Number of minutes between autorefreshes.  IMPORTANT: use 2, 3, 4, 5, 6, 8, 10, 15, 20, or 30 ONLY!!!
	$autoRefreshOff = false; // Begin with Autorefresh Off? true or false -- 'OFF' or 'ON"
	$bgndColor = 'silver'; // Set HAniS Background Color Here
	$btnColor = 'darkslategray'; // Set Button Color here
	$btnTextColor = 'white'; // Set Button Text Color here
	############################ New in Version 2 ##########################
	$pauseSeconds = 2; // Pause on last image, in seconds
	$animRate = 20; // Frame Rate of animation: 5 is glacial, 10 is slow, 15 is leisurely, 20 is good, and 50 is fast - set with integer
	$numbImages = 10; // Number of Radar Images to Animate - 3 to around 10
	############################ New in Version 3 ##########################
	$smoothingOn = true; // Enable image smoothing - new in HAniS 2.5
}
	if (isset($_GET['radar'])) {
    $radar = sanitize($_GET['radar']);
  }
  if (isset($_GET['imageDir'])) {
    $imageDir = sanitize($_GET['imageDir']);
  }
  if (isset($_GET['radarLoc'])) {
    $radarLoc = sanitize($_GET['radarLoc']);
  }
  if (isset($_GET['imageWidth'])) {
    $imageWidth = sanitize($_GET['imageWidth']);
  }
  if (isset($_GET['bgndColor'])) {
    $bgndColor = sanitize($_GET['bgndColor']);
  }
  if (isset($_GET['btnColor'])) {
    $btnColor = sanitize($_GET['btnColor']);
  }
  if (isset($_GET['btnTextColor'])) {
    $btnTextColor = sanitize($_GET['btnTextColor']);
  }
  if (isset($_GET['animRate'])) {
    $animRate = sanitize($_GET['animRate']);
  }
  if (isset($_GET['pauseSeconds'])) {
    $pauseSeconds = sanitize($_GET['pauseSeconds']);
  }
  if (isset($_GET['numbImages'])) {
    $numbImages = sanitize($_GET['numbImages']);
  }
  if (isset($_GET['smoothingOn'])) {
    $smoothingOn = sanitize($_GET['smoothingOn']);
  }
$radInfo = array();
$errorMessage = get_image_fnames($radar,$radarLoc,$listFiles=false);
if ($errorMessage=='Radar Images Currently Unavailable!') {
  echo '<b>No Radar Images Are Currently Available From Here!</b></div>';
  exit;
} else if ($errorMessage=='Too Many Images Requested') {
  echo '<b>Too Many Images Requested from here.  Try Requesting '.$goodImages.' Images.</b></div>';
	exit;
}

?>
  <body style="width:<?php echo $imageWidth?>px" onload="HAniS.setup(
'filenames = <?php get_file_names($radarLoc,'Topo',', ')?> \n\
image_base = https://radar.weather.gov/ridge/standard/ \n\
controls = startstop, speed, step, looprock \n\
controls_style = display:flex;flex-flow:row;background-color:<?php echo $bgndColor?>; \n\
speed_labels = Slower, Faster \n\
rate = <?php echo $animRate?> \n\
pause = <?php echo ($pauseSeconds*1000)?> \n\
skip_missing = 0 \n\
skip_missing_color = #800000 \n\
enable_smoothing = <?php echo ($smoothingOn?'t':'f')?> \n\
overlay_labels_style=font-family:arial;font-size:12px;color:<?php echo $btnColor?>;background-color:<?php echo $bgndColor?>; \n\
background_static = y \n\
buttons_style = flex:auto;margin:2px;background-color:<?php echo $btnColor?>;border-radius:7px;color:<?php echo $btnTextColor?>; \n\
bottom_controls = toggle \n\
toggle_colors = <?php echo $btnColor?>, red, orange \n\
bottom_controls_tooltip = Toggle frames on/off \n\
bottom_controls_style = background-color:<?php echo $bgndColor?>;' ,
'handiv')">

  <div id="handiv" style="width:<?php echo $imageWidth?>px;background-color:#808080;">
  </div>

  </body>
  
 </html>
<?php
############## functions ##############
// ------------------------------------------------------------------
/* begin get_file_names */
function get_file_names($radarLoc,$overlay,$separator){

	global $numbImages;
	for ($i=$numbImages-1; $i>=0; $i--) {
		if(strlen($radarLoc)>3) {
		  $sLoc=strtoupper($radarLoc);
	  } else {
		  $sLoc='K'.strtoupper($radarLoc);
	  }
		echo $sLoc.'_'.$i.'.gif';
		echo $i>0?$separator:'';
	}

}
/* end get_file_names */
// ------------------------------------------------------------------
function get_image_fnames($radar,$radarLoc,$listFiles) {

	global $numbImages,$goodImages;
	$matches = array();
	$theData = get_data('https://radar.weather.gov/ridge/standard/'); // .$radar.'/'.strtoupper($radarLoc).'/');
	if(strlen($radarLoc)>3) {
		$sLoc=strtoupper($radarLoc);
	} else {
		$sLoc='K'.strtoupper($radarLoc);
	}
	preg_match_all('!<a href="('.$sLoc.'_\d\.gif)"!Usi', $theData, $matches);
	print "<!-- matches\n".var_export($matches,true). " -->\n";
	$imageNumber = count($matches[1]);
/* Debug Code *
  echo '$imageNumber: '.$imageNumber.', count($matches[2]): '.count($matches[2]).'<br/>'; // Debug Code
	$i=0;
	foreach($matches[2] as $match) {
			echo 'File No '.$i.': '.$match . '<br>';
			$i++;
}
/* End Debug Code */
	if ($imageNumber<$numbImages) {
//    echo 'https://radar.weather.gov/ridge/RadarImg/'.$radar.'/'.strtoupper($radarLoc).'/';
    if ( $imageNumber==0) {
  		return 'Radar Images Currently Unavailable!';
		} /* else if ($imageNumber<=$numbImages) {
			$goodImages = $imageNumber;
			return 'Too Many Images Requested';
		} */
	} else if ($listFiles) {
  	$imageFile = array();
/*
	  for ($i=($imageNumber-1),$j=$numbImages; $i>=($imageNumber-$numbImages); $i--,$j--) {
		  $imageFile[$j] = $matches[1][$i];
	  }
*/
    $imageFile = array_reverse($matches[1]);
			
	  for ($i=0; $i<$numbImages; $i++) {
		  $image = 'https://radar.weather.gov/ridge/standard/'.$imageFile[$i];
		  echo $image;
		  echo '& ';
		  $radInfo[$i] = $imageFile[$i];
	  }
  }
}
/* end get_image_fnames */
// ------------------------------------------------------------------
/* Begin Function get_data */
function get_data($url)
{
  $ch = curl_init();
  $timeout = 5;
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);                 // don't verify peer certificate
  curl_setopt($ch, CURLOPT_TIMEOUT, 8);                        //  data timeout
  curl_setopt($ch, CURLOPT_NOBODY, false);                     // set nobody
  curl_setopt($ch, CURLOPT_HEADER, true);                      // include header information
  curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (wxnwsradar.php, saratoga-weather.org)');
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
  $data = curl_exec($ch);
  if(PHP_MAJOR_VERSION < 8) {curl_close($ch); }// close the cURL session
  return $data;
}
/* End Function get_data */
// ------------------------------------------------------------------

############ end functions ############
